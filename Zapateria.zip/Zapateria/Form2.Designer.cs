﻿
namespace Zapateria
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAsignaCodigos = new System.Windows.Forms.Button();
            this.btnConsultaCodigos = new System.Windows.Forms.Button();
            this.btn_calzado = new System.Windows.Forms.Button();
            this.btn_localidad = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAsignaCodigos
            // 
            this.btnAsignaCodigos.Location = new System.Drawing.Point(41, 94);
            this.btnAsignaCodigos.Margin = new System.Windows.Forms.Padding(4);
            this.btnAsignaCodigos.Name = "btnAsignaCodigos";
            this.btnAsignaCodigos.Size = new System.Drawing.Size(220, 28);
            this.btnAsignaCodigos.TabIndex = 0;
            this.btnAsignaCodigos.Text = "Asignar codigos";
            this.btnAsignaCodigos.UseVisualStyleBackColor = true;
            this.btnAsignaCodigos.Click += new System.EventHandler(this.btnAsignaCodigos_Click);
            // 
            // btnConsultaCodigos
            // 
            this.btnConsultaCodigos.Location = new System.Drawing.Point(41, 130);
            this.btnConsultaCodigos.Margin = new System.Windows.Forms.Padding(4);
            this.btnConsultaCodigos.Name = "btnConsultaCodigos";
            this.btnConsultaCodigos.Size = new System.Drawing.Size(220, 28);
            this.btnConsultaCodigos.TabIndex = 1;
            this.btnConsultaCodigos.Text = "Consultar codigos";
            this.btnConsultaCodigos.UseVisualStyleBackColor = true;
            this.btnConsultaCodigos.Click += new System.EventHandler(this.btnConsultaCodigos_Click);
            // 
            // btn_calzado
            // 
            this.btn_calzado.Location = new System.Drawing.Point(41, 26);
            this.btn_calzado.Name = "btn_calzado";
            this.btn_calzado.Size = new System.Drawing.Size(220, 28);
            this.btn_calzado.TabIndex = 3;
            this.btn_calzado.Text = "Agregar calzado";
            this.btn_calzado.UseVisualStyleBackColor = true;
            this.btn_calzado.Click += new System.EventHandler(this.btn_calzado_Click);
            // 
            // btn_localidad
            // 
            this.btn_localidad.Location = new System.Drawing.Point(41, 60);
            this.btn_localidad.Name = "btn_localidad";
            this.btn_localidad.Size = new System.Drawing.Size(220, 27);
            this.btn_localidad.TabIndex = 4;
            this.btn_localidad.Text = "Agregar localidad";
            this.btn_localidad.UseVisualStyleBackColor = true;
            this.btn_localidad.Click += new System.EventHandler(this.btn_localidad_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(311, 191);
            this.Controls.Add(this.btn_localidad);
            this.Controls.Add(this.btn_calzado);
            this.Controls.Add(this.btnConsultaCodigos);
            this.Controls.Add(this.btnAsignaCodigos);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMenu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnAsignaCodigos;
        private System.Windows.Forms.Button btnConsultaCodigos;
        private System.Windows.Forms.Button btn_calzado;
        private System.Windows.Forms.Button btn_localidad;
    }
}