﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Zapateria
{
    public partial class frmConsultar : Form
    {
        SqlConnection cnx;
        public frmConsultar()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            try
            {
                string codigo = txtCodigo.Text.Trim();
                int count = 0;
                if (codigo != "") {
                    cnx = new SqlConnection("Server= localhost; Database= zapateria; Integrated Security=True;");
                    cnx.Open();
                    string query = "select c.codigo as 'Codigo',a.pasillo as 'Pasillo',a.numero_anaquel as 'Anaquel',a.nivel_anaquel as 'Nivel',a.lado as 'Lado'," +
                        "d.nombre as 'Marca',c.precio as 'Precio',c.unidades as 'Unidades' " +
                        "from localidad a inner join rel_calzado_localidad b on a.id_localidad = b.id_localidad " +
                        "inner join calzado c on c.id_zapato = b.id_zapato " +
                        "inner join cat_marcas d on d.id_marca = c.id_marca where c.codigo='"+ codigo + "';";
                    SqlCommand cmd = new SqlCommand(query, cnx);
                    //count = Convert.ToInt32(cmd.ExecuteScalar());
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    count = ds.Tables[0].Rows.Count;
                    if (count >= 1)
                    {
                        cmd = new SqlCommand(query, cnx);
                        SqlDataAdapter data = new SqlDataAdapter(cmd);
                        DataTable tabla = new DataTable();
                        data.Fill(tabla);
                        dataGridView1.DataSource = tabla;
                    }
                    else
                        MessageBox.Show("No se encontro el codigo capturado en la base de datos.", "Sin resultados");
                    cnx.Close();
            
                }
                else
                    MessageBox.Show("Captura el codigo a consultar.", "Datos incorrectos");
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message, "Error");
            }
        }

        private void frmConsultar_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmMenu frm = new frmMenu();
            frm.Show();
        }
    }
}
