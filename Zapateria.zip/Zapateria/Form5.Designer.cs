﻿
namespace Zapateria
{
    partial class frmAgregarLocalidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuardar = new System.Windows.Forms.Button();
            this.txt_pasillo = new System.Windows.Forms.TextBox();
            this.txt_numero_anaquel = new System.Windows.Forms.TextBox();
            this.txt_nivel = new System.Windows.Forms.TextBox();
            this.txt_lado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(89, 118);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 0;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // txt_pasillo
            // 
            this.txt_pasillo.Location = new System.Drawing.Point(64, 6);
            this.txt_pasillo.Name = "txt_pasillo";
            this.txt_pasillo.Size = new System.Drawing.Size(100, 22);
            this.txt_pasillo.TabIndex = 1;
            // 
            // txt_numero_anaquel
            // 
            this.txt_numero_anaquel.Location = new System.Drawing.Point(64, 34);
            this.txt_numero_anaquel.Name = "txt_numero_anaquel";
            this.txt_numero_anaquel.Size = new System.Drawing.Size(100, 22);
            this.txt_numero_anaquel.TabIndex = 2;
            // 
            // txt_nivel
            // 
            this.txt_nivel.Location = new System.Drawing.Point(64, 62);
            this.txt_nivel.Name = "txt_nivel";
            this.txt_nivel.Size = new System.Drawing.Size(100, 22);
            this.txt_nivel.TabIndex = 3;
            // 
            // txt_lado
            // 
            this.txt_lado.Location = new System.Drawing.Point(64, 90);
            this.txt_lado.Name = "txt_lado";
            this.txt_lado.Size = new System.Drawing.Size(100, 22);
            this.txt_lado.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(170, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Pasillo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(170, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Numero de anaquel";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(170, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Nivel de anaquel";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(170, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Lado";
            // 
            // frmAgregarLocalidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 187);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_lado);
            this.Controls.Add(this.txt_nivel);
            this.Controls.Add(this.txt_numero_anaquel);
            this.Controls.Add(this.txt_pasillo);
            this.Controls.Add(this.btnGuardar);
            this.Name = "frmAgregarLocalidad";
            this.Text = "Agregar Localidad";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmAgregarLocalidad_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox txt_pasillo;
        private System.Windows.Forms.TextBox txt_numero_anaquel;
        private System.Windows.Forms.TextBox txt_nivel;
        private System.Windows.Forms.TextBox txt_lado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}